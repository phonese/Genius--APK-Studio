package com.geniusapk.studio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.webkit.WebSettings;
import java.io.InputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK_ZIP=41, PICK_APK=42;
    private static final long MAX_ZIP_BYTES=100L*1024L*1024L;
    private static final int MAX_ENTRIES=12000;
    private WebView webView;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        webView=new WebView(this);
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Object(){
            @android.webkit.JavascriptInterface public void pickZip(){runOnUiThread(()->pick(PICK_ZIP,"application/zip"));}
            @android.webkit.JavascriptInterface public void pickApk(){runOnUiThread(()->pick(PICK_APK,"application/vnd.android.package-archive"));}
            @android.webkit.JavascriptInterface public void copyText(String value){runOnUiThread(()->{
                ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Genius APK Studio",value));
                Toast.makeText(MainActivity.this,"कॉपी हो गया",Toast.LENGTH_SHORT).show();
            });}
            @android.webkit.JavascriptInterface public void shareText(String value){runOnUiThread(()->{
                Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT,value);
                startActivity(Intent.createChooser(send,"शेयर करें"));
            });}
        },"AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    private void pick(int code,String mime){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType(mime);i.addCategory(Intent.CATEGORY_OPENABLE);
        try{startActivityForResult(i,code);}
        catch(Exception e){Toast.makeText(this,"फ़ाइल picker उपलब्ध नहीं है",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(requestCode==PICK_APK){
            try{
                Intent install=new Intent(Intent.ACTION_VIEW);
                install.setDataAndType(uri,"application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(install);
            }catch(Exception e){Toast.makeText(this,"APK installer नहीं खुला: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            return;
        }
        if(requestCode==PICK_ZIP){
            try{
                JSONObject result=inspectZip(uri);
                webView.evaluateJavascript("zipAnalyzed("+JSONObject.quote(result.toString())+")",null);
            }catch(Exception e){
                JSONObject err=new JSONObject();
                try{err.put("error","ZIP पढ़ी नहीं जा सकी: "+e.getMessage());}catch(Exception ignored){}
                webView.evaluateJavascript("zipAnalyzed("+JSONObject.quote(err.toString())+")",null);
            }
        }
    }
    private JSONObject inspectZip(Uri uri)throws Exception{
        JSONObject out=new JSONObject();JSONArray sample=new JSONArray();
        int count=0;long total=0;
        boolean settings=false,appGradle=false,gradlew=false,pubspec=false,packageJson=false,manifest=false;
        try(InputStream raw=getContentResolver().openInputStream(uri)){
            if(raw==null)throw new Exception("फ़ाइल stream नहीं खुली");
            try(ZipInputStream zis=new ZipInputStream(raw)){
                ZipEntry entry;byte[] buffer=new byte[8192];
                while((entry=zis.getNextEntry())!=null){
                    if(++count>MAX_ENTRIES)throw new Exception("ZIP में बहुत अधिक entries हैं (सीमा 12,000)");
                    String name=entry.getName().replace('\\','/');
                    if(name.startsWith("/")||name.equals("..")||name.startsWith("../")||name.contains("/../"))throw new Exception("असुरक्षित ZIP path मिला");
                    if(sample.length()<80)sample.put(name);
                    String lower=name.toLowerCase(java.util.Locale.ROOT);
                    if(lower.endsWith("settings.gradle")||lower.endsWith("settings.gradle.kts"))settings=true;
                    if(lower.endsWith("app/build.gradle")||lower.endsWith("app/build.gradle.kts"))appGradle=true;
                    if(lower.endsWith("gradlew"))gradlew=true;
                    if(lower.endsWith("pubspec.yaml"))pubspec=true;
                    if(lower.endsWith("package.json"))packageJson=true;
                    if(lower.endsWith("androidmanifest.xml"))manifest=true;
                    int n;while((n=zis.read(buffer))!=-1){total+=n;if(total>MAX_ZIP_BYTES)throw new Exception("Uncompressed ZIP content 100 MB से अधिक है");}
                    zis.closeEntry();
                }
            }
        }
        out.put("count",count);out.put("sample",sample);out.put("settings",settings);
        out.put("appGradle",appGradle);out.put("gradlew",gradlew);out.put("pubspec",pubspec);
        out.put("packageJson",packageJson);out.put("manifest",manifest);out.put("expandedBytes",total);
        return out;
    }
    @Override public void onBackPressed(){
        if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();
    }
}
