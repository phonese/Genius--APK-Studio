# Genius APK Studio v3.0 — Complete Upgrade

## App में शामिल
1. AI-ready brief generator और वास्तविक AI generation UI
2. Live HTML app preview
3. Visual editor और HTML/CSS/JS source editor
4. Android WebView project ZIP export (backend के जरिए)
5. Service, Business, Shop, Task और Blank templates
6. Local project save/open तथा JSON backup import/export
7. Common Gradle/Android error diagnosis
8. APK file चुनकर Android installer खोलना
9. GitHub Actions से Debug APK, unsigned AAB, signed AAB और signed APK build

## पहले Android app build करें
1. GitHub repository में इस ZIP के अंदर `Genius_APK_Studio` folder की सभी files repository root में upload करें; ZIP को अकेले upload न करें।
2. Actions → Genius APK Studio Build → Run workflow खोलें।
3. पहले `debug-apk` चुनकर build करें।
4. सफल run के Artifacts से APK ZIP डाउनलोड करें, extract करें और APK install करें।

## वास्तविक AI चालू करने के लिए (एक बार setup)
AI key को Android app में कभी न डालें। `backend` folder को Node.js hosting (जैसे Render/Railway/Fly या अपने server) पर deploy करें:
- Node.js 20+ रखें।
- `backend` folder में `npm install` और `npm start` चलाएँ।
- Hosting dashboard के Environment/Secrets में `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`, `ALLOWED_ORIGIN` सेट करें।
- `AI_API_KEY` provider से प्राप्त निजी key है; इसे chat, source code या GitHub में commit न करें। `APP_ACCESS_TOKEN` एक अलग लंबा random token है; वही ऐप के Backend Access Token field में डालें।
- Backend का HTTPS URL ऐप के AI Generator section में डालें।
- `GET /health` से backend health check करें।
- AI feature OpenAI-compatible Chat Completions endpoint स्वीकार करता है। Default model `gpt-4.1-mini` है; अपने provider/account में उपलब्ध model के अनुसार बदलें।
- Usage पर provider शुल्क/limits लागू हो सकते हैं।

## Android Project Export
AI से बने HTML app को Android WebView project ZIP में बदलने के लिए backend URL सेट करें और Build tab में `Android Studio Project ZIP बनाएं` दबाएँ। ZIP में Gradle Android project और GitHub Actions workflow होगा। यह WebView आधारित Android app है, native Kotlin/Java screens का automatic conversion नहीं।

## Signed APK/AAB के लिए
पहले एक Android keystore बनाएं और सुरक्षित backup रखें। GitHub repository → Settings → Secrets and variables → Actions में ये चार repository secrets जोड़ें:
- `ANDROID_KEYSTORE_BASE64`: keystore file का base64 text
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Keystore को कभी GitHub repository में upload न करें। Secrets जोड़ने के बाद workflow में `signed-release-aab` या `signed-release-apk` चुनें। `unsigned-release-aab` बिना signing के बनेगा और Play Store upload के लिए तैयार नहीं होगा। Keystore खोने पर उसी signing identity से भविष्य के updates sign करना कठिन/असंभव हो सकता है; सुरक्षित backup रखें।

## सीमाएँ जो साफ समझें
- AI generation के लिए backend hosting और provider API key आवश्यक हैं; इनके बिना AI बटन काम नहीं करेगा।
- Generated apps फिलहाल WebView-based हैं; native feature conversion (Bluetooth, camera workflows, complex background services, etc.) automatic नहीं है।
- Preview browser-based HTML preview है; final Android behavior device पर test करना होगा।
- Error helper common errors के लिए सुझाव देता है; यह build logs को अपने-आप GitHub से fetch नहीं करता।
- APK install करने पर Android की अनुमति/unknown-app install settings माँगी जा सकती हैं।

## Keystore बनाने का उदाहरण
अपने कंप्यूटर/सुरक्षित environment में JDK का `keytool` चलाएँ:
```bash
keytool -genkeypair -v -keystore release.keystore -alias genius-release -keyalg RSA -keysize 2048 -validity 10000
```
फिर keystore को Base64 में बदलें:
- Linux/macOS: `base64 -w 0 release.keystore`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('release.keystore'))`
आउटपुट को GitHub secret `ANDROID_KEYSTORE_BASE64` में रखें। बाकी तीन secrets वही passwords और alias होंगे जो keytool में चुने थे। Keystore और passwords का सुरक्षित offline backup रखें।

\n## v3 Preview synchronization fix\n- Preview खोलते समय Source Editor के सबसे नए HTML को source of truth माना जाता है।\n- Android WebView में stale iframe content से बचने के लिए preview iframe को हर refresh पर recreate किया जाता है।\n- AI generation के बाद generated HTML editor और preview दोनों में sync किया जाता है।\n