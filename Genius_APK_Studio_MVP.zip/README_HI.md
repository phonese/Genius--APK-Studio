# Genius APK Studio — Android MVP

यह शुरुआती Android Studio प्रोजेक्ट है। यह मोबाइल-अनुकूल WebView इंटरफ़ेस देता है:
- नए ऐप का विचार/requirements लिखना
- पुराने project ZIP चुनना
- ZIP की सामग्री और build readiness के बारे में बुनियादी जाँच
- build workflow के लिए निर्देश

**महत्वपूर्ण सीमा:** यह MVP अकेले फोन पर किसी भी arbitrary project को compile करके APK नहीं बना सकता। वास्तविक APK निर्माण के लिए Android SDK/Gradle build engine चाहिए। इस प्रोजेक्ट में कोई cloud compiler या AI API key शामिल नहीं है। ZIP चुनने पर ऐप केवल फ़ाइल चुनता है; अभी वह ZIP को सुरक्षित रूप से unpack/compile नहीं करता।

## APK बनाने के लिए
1. Android Studio वाले कंप्यूटर पर यह प्रोजेक्ट खोलें।
2. Gradle sync करें और Android SDK स्थापित रखें।
3. `Build > Build APK(s)` चुनें।
4. मोबाइल पर चलाने के लिए बने APK को कॉपी/इंस्टॉल करें।

इसे वास्तविक cloud build सेवा से जोड़ने के लिए backend, authentication, upload limits, isolated build workers और secure artifact download जोड़ना होगा।
