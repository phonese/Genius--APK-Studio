package com.geniusapk.studio;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int PICK_ZIP = 41;
    private static final long MAX_ZIP_BYTES = 100L * 1024L * 1024L;
    private static final int MAX_ENTRIES = 12000;
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface public void pickZip() {
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.setType("application/zip");
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    try { startActivityForResult(i, PICK_ZIP); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "फ़ाइल picker उपलब्ध नहीं है", Toast.LENGTH_LONG).show(); }
                });
            }
            @android.webkit.JavascriptInterface public void copyText(String value) {
                runOnUiThread(() -> {
                    ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Genius APK Studio", value));
                    Toast.makeText(MainActivity.this, "कॉपी हो गया", Toast.LENGTH_SHORT).show();
                });
            }
            @android.webkit.JavascriptInterface public void shareText(String value) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, value);
                    startActivity(Intent.createChooser(send, "Workflow शेयर करें"));
                });
            }
        }, "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_ZIP || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            JSONObject result = inspectZip(uri);
            webView.evaluateJavascript("zipAnalyzed(" + JSONObject.quote(result.toString()) + ")", null);
        } catch (Exception e) {
            JSONObject err = new JSONObject();
            try { err.put("error", "ZIP पढ़ी नहीं जा सकी: " + e.getMessage()); } catch (Exception ignored) {}
            webView.evaluateJavascript("zipAnalyzed(" + JSONObject.quote(err.toString()) + ")", null);
        }
    }

    private JSONObject inspectZip(Uri uri) throws Exception {
        JSONObject out = new JSONObject();
        JSONArray sample = new JSONArray();
        Set<String> names = new HashSet<>();
        int count = 0; long total = 0;
        boolean settings = false, appGradle = false, gradlew = false, pubspec = false, packageJson = false, manifest = false;
        try (InputStream raw = getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new Exception("फ़ाइल stream नहीं खुली");
            try (ZipInputStream zis = new ZipInputStream(raw)) {
                ZipEntry entry;
                byte[] buffer = new byte[8192];
                while ((entry = zis.getNextEntry()) != null) {
                    if (++count > MAX_ENTRIES) throw new Exception("ZIP में बहुत अधिक entries हैं (सीमा 12,000)");
                    String name = entry.getName();
                    if (name.startsWith("/") || name.contains("../") || name.equals("..")) throw new Exception("असुरक्षित ZIP path मिला");
                    names.add(name);
                    if (sample.length() < 80) sample.put(name);
                    String lower = name.toLowerCase();
                    if (lower.endsWith("settings.gradle") || lower.endsWith("settings.gradle.kts")) settings = true;
                    if (lower.endsWith("app/build.gradle") || lower.endsWith("app/build.gradle.kts")) appGradle = true;
                    if (lower.endsWith("gradlew")) gradlew = true;
                    if (lower.endsWith("pubspec.yaml")) pubspec = true;
                    if (lower.endsWith("package.json")) packageJson = true;
                    if (lower.endsWith("androidmanifest.xml")) manifest = true;
                    int n; while ((n = zis.read(buffer)) != -1) { total += n; if (total > MAX_ZIP_BYTES) throw new Exception("Uncompressed ZIP content 100 MB से अधिक है"); }
                    zis.closeEntry();
                }
            }
        }
        out.put("count", count); out.put("sample", sample); out.put("settings", settings);
        out.put("appGradle", appGradle); out.put("gradlew", gradlew); out.put("pubspec", pubspec);
        out.put("packageJson", packageJson); out.put("manifest", manifest); out.put("expandedBytes", total);
        return out;
    }
}
