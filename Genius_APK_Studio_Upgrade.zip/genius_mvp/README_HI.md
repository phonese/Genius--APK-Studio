# Genius APK Studio — MVP Upgrade

यह Android ऐप अब चुनी गई ZIP के अंदर की entries को डिवाइस पर पढ़कर project के संकेत जाँचता है। यह सीमित आकार/entry count रखता है, असुरक्षित ZIP paths को अस्वीकार करता है, ऐप का development brief बनाता है और Android Gradle project के लिए GitHub Actions workflow उपलब्ध कराता है।

## शामिल सुविधाएँ
- ऐप का development brief बनाना और कॉपी/शेयर करना
- Android Storage Access Framework से ZIP चुनना
- ZIP entries की वास्तविक जाँच; Android Gradle / Flutter / package.json संकेत पहचानना
- GitHub Actions `assembleDebug` workflow दिखाना
- APK artifact डाउनलोड करने के स्पष्ट चरण

## महत्वपूर्ण सीमा
इस ऐप में AI model/API या cloud compiler शामिल नहीं है। यह arbitrary project को स्वयं compile नहीं करता। APK GitHub Actions जैसे build runner पर बनेगा। AI features के लिए सुरक्षित backend, provider authentication, rate limits और secret management अलग से जोड़ने होंगे।

## Android build
- JDK 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Android SDK 35
- Android Studio में project खोलें और Gradle sync करें, फिर `Build > Build APK(s)` चलाएँ।

## किसी Android Gradle project का APK GitHub पर बनाना
1. Project ZIP को extract करें।
2. Extract की हुई project files repository के root में upload करें; केवल ZIP upload न करें।
3. `.github/workflows/android.yml` workflow file जोड़ें। इस repository में sample workflow मौजूद है।
4. GitHub के Actions tab में `Android APK Build` run करें।
5. सफल run खोलकर Artifacts से `app-debug` डाउनलोड करें और ZIP extract करके APK install करें।

## सुरक्षा
ZIP inspection के दौरान 100 MB expanded data और 12,000 entries की सीमा लागू है। Path traversal जैसे `../` paths reject किए जाते हैं। ZIP contents execute नहीं किए जाते।
